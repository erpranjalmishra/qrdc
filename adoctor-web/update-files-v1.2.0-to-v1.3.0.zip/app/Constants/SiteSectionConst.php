<?php

namespace App\Constants;

class SiteSectionConst{
    const BANNER_SECTION        = "Banner Section";
    const ABOUT_SECTION         = "About Section";
    const FAQ_SECTION           = "Faq Section";
    const TESTIMONIAL_SECTION   = "Testimonial Section";
    const HOW_ITS_WORK          = "How Its Work";
    const WEB_JOURNAL           = "Web Journal";
    const NEWSLETTER_SECTION    = "News Letter Section";
    const CONTACT_SECTION       = "Contact Section";
    const FOOTER_SECTION        = "Footer Section";
    const LOG_IN_SECTION        = "Login Section";
    const REGISTER_SECTION      = "Register Section";

}