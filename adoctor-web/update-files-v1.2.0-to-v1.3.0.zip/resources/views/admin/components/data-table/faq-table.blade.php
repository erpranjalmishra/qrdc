<table class="custom-table faq-search-table">
    <thead>
        <tr>

            
            <th>Question </th>
            <th >Answer</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>

        
    </tbody>
</table>

